//#region src/ui/popup/popup.ts
var TRANSFER_PREFIX = `We are starting a fresh session. I am pasting the context brief from our previous conversation below. Read it to fully absorb the state of the project, adopt this context as our baseline, and wait for my next instruction without saying anything other than that you are ready.`;
var currentNativeChatId = null;
var summaryMap = /* @__PURE__ */ new Map();
function formatRelativeTime(timestamp) {
	const diff = Date.now() - timestamp;
	const seconds = Math.floor(diff / 1e3);
	const minutes = Math.floor(seconds / 60);
	const hours = Math.floor(minutes / 60);
	const days = Math.floor(hours / 24);
	if (days > 10) {
		const d = new Date(timestamp);
		return `${d.getDate()} ${[
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec"
		][d.getMonth()]} ${d.getFullYear()}`;
	}
	if (days > 0) return `${days}d ago`;
	if (hours > 0) return `${hours}h ago`;
	if (minutes > 0) return `${minutes}m ago`;
	return "just now";
}
function setupTabs() {
	const tabCapture = document.getElementById("tab-capture");
	const tabTransfer = document.getElementById("tab-transfer");
	const capturePanel = document.getElementById("capture-panel");
	const transferPanel = document.getElementById("transfer-panel");
	tabCapture.addEventListener("click", () => {
		tabCapture.classList.add("active");
		tabTransfer.classList.remove("active");
		capturePanel.classList.add("active");
		transferPanel.classList.remove("active");
		document.body.classList.add("capture-mode");
		document.body.classList.remove("transfer-mode");
	});
	tabTransfer.addEventListener("click", () => {
		tabTransfer.classList.add("active");
		tabCapture.classList.remove("active");
		transferPanel.classList.add("active");
		capturePanel.classList.remove("active");
		document.body.classList.add("transfer-mode");
		document.body.classList.remove("capture-mode");
		loadAllSummaries();
	});
}
async function loadMessages() {
	const listElement = document.getElementById("message-list");
	const titleElement = document.getElementById("active-chat-title");
	if (!listElement) return;
	try {
		const [activeTab] = await chrome.tabs.query({
			active: true,
			currentWindow: true
		});
		if (!activeTab || !activeTab.id) {
			listElement.innerHTML = "<li><em>No active tab found.</em></li>";
			if (titleElement) titleElement.textContent = "Unknown Context";
			return;
		}
		let meta = null;
		try {
			meta = await chrome.tabs.sendMessage(activeTab.id, { type: "GET_CONVERSATION_INFO" });
		} catch (e) {
			listElement.innerHTML = "<li><em>No supported chat detected on this page.</em></li>";
			if (titleElement) titleElement.textContent = "Inactive / Not a chat page";
			return;
		}
		if (!meta || !meta.nativeId) {
			listElement.innerHTML = "<li><em>Could not detect conversation.</em></li>";
			if (titleElement) titleElement.textContent = "Unknown Chat";
			return;
		}
		currentNativeChatId = meta.nativeId;
		if (titleElement) titleElement.textContent = meta.title.length > 50 ? meta.title.substring(0, 50) + "..." : meta.title;
		const messages = (await chrome.runtime.sendMessage({
			type: "GET_CHAT_MESSAGES",
			payload: { nativeChatId: currentNativeChatId }
		})).messages || [];
		listElement.innerHTML = "";
		if (messages.length === 0) {
			listElement.innerHTML = "<li><em>No messages captured in this chat yet.</em></li>";
			return;
		}
		messages.reverse().slice(0, 50).forEach((msg) => {
			const li = document.createElement("li");
			li.className = `message-item ${msg.role}`;
			const roleBadge = document.createElement("span");
			roleBadge.className = "role-badge";
			roleBadge.textContent = msg.role;
			const textPreview = document.createElement("div");
			textPreview.className = "text-preview";
			textPreview.textContent = msg.text.length > 100 ? msg.text.substring(0, 100) + "..." : msg.text;
			li.appendChild(roleBadge);
			li.appendChild(textPreview);
			listElement.appendChild(li);
		});
	} catch (error) {
		console.error("Failed to load messages:", error);
		listElement.innerHTML = "<li class=\"error\">Error loading messages</li>";
	}
}
function createCardElement(card) {
	const btn = document.createElement("button");
	btn.className = "transfer-card";
	btn.setAttribute("aria-label", `Transfer: ${card.title}`);
	const content = document.createElement("div");
	content.className = "transfer-card__content";
	const titleEl = document.createElement("div");
	titleEl.className = "transfer-card__title";
	titleEl.textContent = card.title.length > 35 ? card.title.substring(0, 35) + "…" : card.title;
	const metaRow = document.createElement("div");
	metaRow.className = "transfer-card__meta";
	const dateEl = document.createElement("span");
	dateEl.className = "transfer-card__date";
	dateEl.textContent = formatRelativeTime(card.updatedAt);
	const versionEl = document.createElement("span");
	versionEl.className = "transfer-card__version";
	versionEl.textContent = `v${card.version}`;
	metaRow.appendChild(dateEl);
	metaRow.appendChild(versionEl);
	content.appendChild(titleEl);
	content.appendChild(metaRow);
	btn.appendChild(content);
	btn.addEventListener("click", () => handleCardClick(card.id));
	return btn;
}
function renderTransferCards(conversations) {
	const container = document.getElementById("transfer-cards-container");
	const emptyMsg = document.getElementById("transfer-empty-msg");
	if (!container) return;
	container.querySelectorAll(".transfer-card").forEach((c) => c.remove());
	summaryMap.clear();
	conversations.forEach((c) => {
		summaryMap.set(c.id, c.summary);
	});
	if (conversations.length === 0) {
		if (emptyMsg) emptyMsg.style.display = "block";
		return;
	}
	if (emptyMsg) emptyMsg.style.display = "none";
	console.log(`[Transfer] Rendering ${conversations.length} conversation cards.`);
	conversations.forEach((conv) => {
		try {
			const card = createCardElement(conv);
			container.appendChild(card);
		} catch (e) {
			console.error("[Transfer] Failed to create card for", conv, e);
		}
	});
}
async function loadAllSummaries() {
	try {
		const response = await chrome.runtime.sendMessage({ type: "GET_ALL_SUMMARIES" });
		if (response?.conversations) renderTransferCards(response.conversations);
	} catch (err) {
		console.error("Failed to load summaries:", err);
	}
}
async function handleCardClick(conversationId) {
	const summary = summaryMap.get(conversationId);
	if (!summary) return;
	const textToInject = `${TRANSFER_PREFIX}\n\n${summary}`;
	const [activeTab] = await chrome.tabs.query({
		active: true,
		currentWindow: true
	});
	if (!activeTab?.id) return;
	try {
		await chrome.tabs.sendMessage(activeTab.id, {
			type: "INJECT_AND_SEND",
			payload: { text: textToInject }
		});
	} catch (err) {
		console.error("Inject failed, attempting scripting.executeScript fallback:", err);
		try {
			await chrome.scripting.executeScript({
				target: { tabId: activeTab.id },
				func: injectTextIntoPage,
				args: [textToInject]
			});
		} catch (fallbackErr) {
			console.error("Fallback injection also failed:", fallbackErr);
		}
	}
}
var POKEBALL_ANIMATION = {
	OPEN_MS: 500,
	GOTCHA_MS: 820
};
function setPokeballState(state) {
	const ball = document.getElementById("pokeball-sprite");
	if (!ball) return;
	ball.classList.remove("idle", "open", "rock", "bounce");
	ball.classList.add(state);
}
function showGotchaEffect() {
	const effect = document.getElementById("capture-gotcha");
	if (!effect) return;
	effect.classList.remove("is-visible");
	effect.offsetWidth;
	effect.classList.add("is-visible");
	window.setTimeout(() => {
		effect.classList.remove("is-visible");
	}, POKEBALL_ANIMATION.GOTCHA_MS);
}
function sleep(ms) {
	return new Promise((resolve) => window.setTimeout(resolve, ms));
}
async function playCaptureStartSequence() {
	setPokeballState("open");
	await sleep(POKEBALL_ANIMATION.OPEN_MS);
	setPokeballState("rock");
}
function finishCaptureSequence() {
	showGotchaEffect();
	window.setTimeout(() => {
		setPokeballState("idle");
	}, POKEBALL_ANIMATION.GOTCHA_MS);
}
function setupListeners() {
	const refreshBtn = document.getElementById("refresh-transfer-btn");
	if (refreshBtn) refreshBtn.addEventListener("click", async () => {
		const originalText = refreshBtn.textContent;
		refreshBtn.textContent = "...";
		await loadAllSummaries();
		refreshBtn.textContent = originalText;
	});
	const captureBtn = document.getElementById("capture-btn");
	const captureStatus = document.getElementById("capture-status");
	if (captureBtn) captureBtn.addEventListener("click", async () => {
		const [activeTab] = await chrome.tabs.query({
			active: true,
			currentWindow: true
		});
		if (!activeTab?.id) return;
		const url = activeTab.url || "";
		if (![
			"chatgpt.com",
			"chat.openai.com",
			"gemini.google.com",
			"chat.deepseek.com",
			"claude.ai"
		].some((domain) => url.includes(domain))) {
			if (captureStatus) {
				captureStatus.style.display = "block";
				captureStatus.classList.add("status-bar--error");
				captureStatus.textContent = "Capture failed: Please open a supported chat page (ChatGPT, Claude, Gemini, DeepSeek).";
			}
			return;
		}
		captureBtn.setAttribute("disabled", "true");
		const animationSequence = playCaptureStartSequence();
		let captureSucceeded = false;
		if (captureStatus) {
			captureStatus.style.display = "none";
			captureStatus.classList.remove("status-bar--error");
			captureStatus.textContent = "";
		}
		const progressListener = (message) => {};
		chrome.runtime.onMessage.addListener(progressListener);
		try {
			const response = await chrome.tabs.sendMessage(activeTab.id, { type: "TRIGGER_CAPTURE" });
			if (response?.success) {
				await loadMessages();
				const mlListener = (message) => {};
				chrome.runtime.onMessage.addListener(mlListener);
				try {
					const sumResponse = await chrome.runtime.sendMessage({
						type: "SUMMARIZE_CONVERSATION",
						payload: { nativeChatId: currentNativeChatId }
					});
					if (sumResponse.error) {
						if (captureStatus) {
							captureStatus.style.display = "block";
							captureStatus.classList.add("status-bar--error");
							captureStatus.textContent = `Summary error: ${sumResponse.error}`;
						}
					} else if (sumResponse.summary) {
						await loadAllSummaries();
						captureSucceeded = true;
						await animationSequence;
						finishCaptureSequence();
					}
				} catch (sumErr) {
					const msg = sumErr?.message ? String(sumErr.message) : String(sumErr);
					if (captureStatus) {
						captureStatus.style.display = "block";
						captureStatus.classList.add("status-bar--error");
						captureStatus.textContent = `Summary error: ${msg}`;
					}
				} finally {
					chrome.runtime.onMessage.removeListener(mlListener);
				}
			} else {
				const err = response?.error || "Unknown error";
				if (captureStatus) {
					captureStatus.style.display = "block";
					captureStatus.classList.add("status-bar--error");
					captureStatus.textContent = `Capture failed: ${err}`;
				}
			}
		} catch (err) {
			if (captureStatus) {
				captureStatus.style.display = "block";
				captureStatus.classList.add("status-bar--error");
				const errMsg = err?.message || "";
				if (errMsg.includes("Receiving end does not exist") || errMsg.includes("establish connection")) captureStatus.textContent = "Connection failed. Please refresh the chat page and try again.";
				else captureStatus.textContent = `Capture error: ${errMsg || "Could not reach content script."}`;
			}
		} finally {
			chrome.runtime.onMessage.removeListener(progressListener);
			captureBtn.removeAttribute("disabled");
			if (!captureSucceeded) {
				await animationSequence;
				setPokeballState("idle");
			}
		}
	});
}
/**
* Injected into the active page to paste text into the chat input and send it.
* Works for ChatGPT, Claude, Gemini, DeepSeek by trying common selectors.
*/
function injectTextIntoPage(text) {
	const selectors = [
		"#prompt-textarea",
		"div[contenteditable=\"true\"].ProseMirror",
		"div[contenteditable=\"true\"]",
		"textarea"
	];
	let input = null;
	for (const sel of selectors) {
		input = document.querySelector(sel);
		if (input) break;
	}
	if (!input) {
		console.error("[Transfer] Could not find chat input on this page.");
		return;
	}
	if (input.getAttribute("contenteditable") === "true") {
		input.focus();
		input.innerHTML = "";
		text.split("\n").forEach((line, i) => {
			const p = document.createElement("p");
			p.textContent = line || "​";
			input.appendChild(p);
		});
		input.dispatchEvent(new Event("input", { bubbles: true }));
	} else if (input instanceof HTMLTextAreaElement) {
		(Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set)?.call(input, text);
		input.dispatchEvent(new Event("input", { bubbles: true }));
	}
	setTimeout(() => {
		const sendSelectors = [
			"button[data-testid=\"send-button\"]",
			"button[aria-label=\"Send Message\"]",
			"button.send-button",
			"button[aria-label=\"Send\"]",
			"button[type=\"submit\"]"
		];
		let sendBtn = null;
		for (const sel of sendSelectors) {
			sendBtn = document.querySelector(sel);
			if (sendBtn) break;
		}
		if (sendBtn) sendBtn.click();
		else {
			const enterEvent = new KeyboardEvent("keydown", {
				key: "Enter",
				code: "Enter",
				bubbles: true,
				cancelable: true
			});
			input.dispatchEvent(enterEvent);
		}
	}, 300);
}
async function init() {
	setupTabs();
	setPokeballState("idle");
	await loadAllSummaries();
	await loadMessages();
	setupListeners();
}
document.addEventListener("DOMContentLoaded", init);
//#endregion
