//#region src/content/dom-extractor.ts
function extractMessageFromNode(node, conversationId) {
	const role = node.getAttribute("data-message-author-role");
	if (!role) return null;
	let text = "";
	const markdownNode = node.querySelector(".markdown");
	if (markdownNode) text = markdownNode.innerText;
	else text = node.innerText || node.textContent || "";
	text = text.trim();
	if (!text) return null;
	const roleNormalized = role.toLowerCase();
	if (roleNormalized !== "user" && roleNormalized !== "assistant") return null;
	return {
		id: node.getAttribute("data-message-id") || crypto.randomUUID(),
		role: roleNormalized,
		text,
		timestamp: Date.now(),
		chatId: conversationId
	};
}
function scanFullDom(conversationId) {
	console.log("[Extract] Scanning full DOM for messages");
	const messageNodes = document.querySelectorAll("[data-message-author-role]");
	const messages = [];
	const seenIds = /* @__PURE__ */ new Set();
	messageNodes.forEach((node) => {
		const msg = extractMessageFromNode(node, conversationId);
		if (msg && !seenIds.has(msg.id)) {
			seenIds.add(msg.id);
			messages.push(msg);
		}
	});
	console.log(`[Extract] Found ${messages.length} messages in DOM`);
	return messages;
}
//#endregion
//#region src/content/scroll-engine.ts
async function scrollToTopToLoadHistory(scrollElement, maxAttempts = 25) {
	console.log("[Scroll] Initiating DOM auto-scroll for history fallback");
	let stablePasses = 0;
	for (let i = 0; i < maxAttempts; i++) {
		const prevHeight = scrollElement.scrollHeight;
		const prevMessageCount = document.querySelectorAll("[data-message-author-role]").length;
		if ("scrollTop" in scrollElement) scrollElement.scrollTop = 0;
		scrollElement.dispatchEvent(new Event("scroll", { bubbles: true }));
		window.dispatchEvent(new Event("scroll"));
		await new Promise((resolve) => setTimeout(resolve, 900));
		const newHeight = scrollElement.scrollHeight;
		const newMessageCount = document.querySelectorAll("[data-message-author-role]").length;
		if (newHeight === prevHeight && newMessageCount === prevMessageCount) {
			stablePasses += 1;
			if (stablePasses >= 2) {
				console.log(`[Scroll] Reached top after ${i + 1} attempts (${newMessageCount} messages visible)`);
				break;
			}
		} else stablePasses = 0;
	}
}
//#endregion
//#region src/content/providers/chatgpt.ts
function extractTextFromParts(parts) {
	if (!parts?.length) return "";
	return parts.map((part) => {
		if (typeof part === "string") return part;
		if (part && typeof part === "object") {
			const record = part;
			if (typeof record.text === "string") return record.text;
			if (typeof record.content === "string") return record.content;
		}
		return "";
	}).filter(Boolean).join("\n").trim();
}
function extractMessageText(message) {
	const content = message.content;
	if (!content) return "";
	if (content.content_type === "text" || content.content_type === "multimodal_text") return extractTextFromParts(content.parts);
	if (typeof content.text === "string") return content.text.trim();
	return extractTextFromParts(content.parts);
}
function resolveCanonicalPath(mapping, currentNode) {
	if (!Object.keys(mapping).length) return [];
	if (currentNode && mapping[currentNode]) {
		const path = [];
		let nodeId = currentNode;
		while (nodeId && mapping[nodeId]) {
			const current = mapping[nodeId];
			if (current.message?.content) path.push(current.message);
			nodeId = current.parent ?? null;
		}
		return path.reverse();
	}
	const roots = Object.entries(mapping).filter(([, node]) => !node.parent || !mapping[node.parent]).map(([id]) => id);
	if (!roots.length) return [];
	const messages = [];
	function subtreeSize(nodeId) {
		const node = mapping[nodeId];
		if (!node) return 0;
		let size = node.message?.content ? 1 : 0;
		for (const childId of node.children ?? []) size += subtreeSize(childId);
		return size;
	}
	function walk(nodeId) {
		const node = mapping[nodeId];
		if (!node) return;
		if (node.message?.content) messages.push(node.message);
		const children = node.children ?? [];
		if (!children.length) return;
		walk(children.reduce((best, child) => subtreeSize(child) > subtreeSize(best) ? child : best));
	}
	walk(roots[0]);
	return messages;
}
function parseChatGptApiResponse(conversationId, data) {
	const raw = data;
	const apiMessages = resolveCanonicalPath(raw.mapping ?? {}, raw.current_node);
	const messages = [];
	for (const apiMessage of apiMessages) {
		const role = apiMessage.author?.role?.toLowerCase();
		if (role !== "user" && role !== "assistant") continue;
		const text = extractMessageText(apiMessage);
		if (!text) continue;
		const timestamp = typeof apiMessage.create_time === "number" ? Math.round(apiMessage.create_time * 1e3) : Date.now();
		messages.push({
			id: apiMessage.id ?? crypto.randomUUID(),
			role,
			text,
			timestamp,
			chatId: conversationId
		});
	}
	return {
		id: conversationId,
		provider: "chatgpt",
		title: raw.title?.trim() || document.title || "ChatGPT Conversation",
		messages,
		capturedAt: Date.now(),
		embedding: null
	};
}
var ChatGPTAdapter = class {
	provider = "chatgpt";
	detect() {
		const host = window.location.hostname;
		return host === "chatgpt.com" || host === "chat.openai.com";
	}
	getConversationId() {
		const match = window.location.pathname.match(/\/c\/([a-zA-Z0-9-]+)/);
		return match ? match[1] : null;
	}
	async fetchFullConversation(id) {
		console.log(`[Provider] ChatGPTAdapter requesting API capture for ${id}`);
		return new Promise((resolve, reject) => {
			chrome.runtime.sendMessage({
				type: "REQUEST_API_CAPTURE",
				payload: {
					provider: this.provider,
					id,
					apiBase: window.location.origin
				}
			}, (response) => {
				if (chrome.runtime.lastError) {
					console.error("[API] Message error:", chrome.runtime.lastError.message);
					reject(new Error(chrome.runtime.lastError.message));
					return;
				}
				if (response?.success) try {
					const conversation = parseChatGptApiResponse(id, response.data);
					console.log(`[API] Parsed ${conversation.messages.length} messages from API response`);
					if (conversation.messages.length === 0) {
						reject(/* @__PURE__ */ new Error("API returned no user/assistant messages"));
						return;
					}
					resolve(conversation);
				} catch (parseError) {
					console.error("[API] Failed to parse ChatGPT API response");
					reject(parseError instanceof Error ? parseError : new Error(String(parseError)));
				}
				else {
					console.error("[API] ChatGPT API fetch failed:", response?.error);
					reject(new Error(response?.error || "Unknown API error"));
				}
			});
		});
	}
	async extractFromDom() {
		console.log("[Fallback] ChatGPTAdapter initiating DOM fallback");
		await scrollToTopToLoadHistory(findChatGptScrollContainer());
		const conversationId = this.getConversationId() ?? `temp_${crypto.randomUUID()}`;
		const messages = scanFullDom(conversationId);
		return {
			id: conversationId,
			provider: this.provider,
			title: document.title || "ChatGPT Conversation",
			messages,
			capturedAt: Date.now(),
			embedding: null
		};
	}
};
function findChatGptScrollContainer() {
	for (const selector of [
		"main [class*=\"overflow-y-auto\"]",
		"main",
		"[class*=\"react-scroll-to-bottom\"]",
		"div[class*=\"overflow-y-auto\"]"
	]) {
		const element = document.querySelector(selector);
		if (element) return element;
	}
	return document.documentElement;
}
//#endregion
//#region src/content/providers/claude.ts
function extractClaudeMessageText(msg) {
	if (msg.content && Array.isArray(msg.content)) {
		const texts = msg.content.filter((block) => block.type === "text" && block.text).map((block) => block.text);
		if (texts.length > 0) return texts.join("\n").trim();
	}
	if (typeof msg.text === "string") return msg.text.trim();
	return "";
}
function parseClaudeApiResponse(conversationId, data) {
	const raw = data;
	const apiMessages = raw.chat_messages ?? [];
	const messages = [];
	for (const apiMsg of apiMessages) {
		const role = apiMsg.sender === "human" ? "user" : apiMsg.sender === "assistant" ? "assistant" : null;
		if (!role) continue;
		const text = extractClaudeMessageText(apiMsg);
		if (!text) continue;
		const timestamp = apiMsg.created_at ? new Date(apiMsg.created_at).getTime() : Date.now();
		messages.push({
			id: apiMsg.uuid ?? crypto.randomUUID(),
			role,
			text,
			timestamp,
			chatId: conversationId
		});
	}
	return {
		id: conversationId,
		provider: "claude",
		title: raw.name?.trim() || document.title || "Claude Conversation",
		messages,
		capturedAt: Date.now(),
		embedding: null
	};
}
function extractClaudeDomMessages(conversationId) {
	const messages = [];
	const seenIds = /* @__PURE__ */ new Set();
	const messageContainers = document.querySelectorAll("[class*=\"font-user-message\"], [class*=\"font-claude-message\"], [data-testid*=\"human-turn\"], [data-testid*=\"ai-turn\"], .contents .group");
	if (messageContainers.length === 0) {
		document.querySelectorAll("[class*=\"min-h-\"]").forEach((turn, index) => {
			const text = turn.innerText?.trim();
			if (!text) return;
			const id = `claude_dom_${index}`;
			if (seenIds.has(id)) return;
			seenIds.add(id);
			messages.push({
				id,
				role: index % 2 === 0 ? "user" : "assistant",
				text,
				timestamp: Date.now(),
				chatId: conversationId
			});
		});
		return messages;
	}
	messageContainers.forEach((container, index) => {
		const el = container;
		const text = el.innerText?.trim();
		if (!text) return;
		const id = `claude_dom_${index}`;
		if (seenIds.has(id)) return;
		seenIds.add(id);
		const classList = el.className || "";
		const testId = el.getAttribute("data-testid") || "";
		let role = "assistant";
		if (classList.includes("font-user-message") || testId.includes("human")) role = "user";
		messages.push({
			id,
			role,
			text,
			timestamp: Date.now(),
			chatId: conversationId
		});
	});
	return messages;
}
var ClaudeAdapter = class {
	provider = "claude";
	detect() {
		return window.location.hostname === "claude.ai";
	}
	getConversationId() {
		const match = window.location.pathname.match(/\/chat\/([a-zA-Z0-9-]+)/);
		return match ? match[1] : null;
	}
	async fetchFullConversation(id) {
		console.log(`[Provider] ClaudeAdapter requesting API capture for ${id}`);
		return new Promise((resolve, reject) => {
			chrome.runtime.sendMessage({
				type: "REQUEST_API_CAPTURE",
				payload: {
					provider: this.provider,
					id,
					apiBase: window.location.origin
				}
			}, (response) => {
				if (chrome.runtime.lastError) {
					console.error("[API] Message error:", chrome.runtime.lastError.message);
					reject(new Error(chrome.runtime.lastError.message));
					return;
				}
				if (response?.success) try {
					const conversation = parseClaudeApiResponse(id, response.data);
					console.log(`[API] Parsed ${conversation.messages.length} messages from Claude API`);
					if (conversation.messages.length === 0) {
						reject(/* @__PURE__ */ new Error("Claude API returned no user/assistant messages"));
						return;
					}
					resolve(conversation);
				} catch (parseError) {
					console.error("[API] Failed to parse Claude API response");
					reject(parseError instanceof Error ? parseError : new Error(String(parseError)));
				}
				else {
					console.error("[API] Claude API fetch failed:", response?.error);
					reject(new Error(response?.error || "Unknown API error"));
				}
			});
		});
	}
	async extractFromDom() {
		console.log("[Fallback] ClaudeAdapter initiating DOM fallback");
		await scrollToTopToLoadHistory(document.querySelector("[class*=\"overflow-y-auto\"]") ?? document.querySelector("main") ?? document.documentElement);
		const conversationId = this.getConversationId() ?? `claude_temp_${crypto.randomUUID()}`;
		const messages = extractClaudeDomMessages(conversationId);
		return {
			id: conversationId,
			provider: this.provider,
			title: document.title || "Claude Conversation",
			messages,
			capturedAt: Date.now(),
			embedding: null
		};
	}
};
//#endregion
//#region src/content/providers/gemini.ts
function parseGeminiApiResponse(conversationId, data) {
	const raw = data;
	const turns = raw.turns ?? [];
	const messages = [];
	for (const turn of turns) {
		const rawRole = (turn.role ?? "").toUpperCase();
		let role;
		if (rawRole === "USER") role = "user";
		else if (rawRole === "MODEL") role = "assistant";
		else continue;
		const text = (turn.parts ?? []).map((p) => p.text ?? "").filter(Boolean).join("\n").trim();
		if (!text) continue;
		const timestamp = turn.createTime ? new Date(turn.createTime).getTime() : Date.now();
		messages.push({
			id: turn.id ?? crypto.randomUUID(),
			role,
			text,
			timestamp,
			chatId: conversationId
		});
	}
	return {
		id: conversationId,
		provider: "gemini",
		title: raw.title?.trim() || document.title || "Gemini Conversation",
		messages,
		capturedAt: Date.now(),
		embedding: null
	};
}
function extractGeminiDomMessages(conversationId) {
	const messages = [];
	const seenIds = /* @__PURE__ */ new Set();
	const turnContainers = document.querySelectorAll("user-query, model-response, [class*=\"query-content\"], [class*=\"model-response\"], .conversation-container .turn-content, message-content");
	if (turnContainers.length > 0) {
		turnContainers.forEach((container, index) => {
			const el = container;
			const text = el.innerText?.trim();
			if (!text) return;
			const id = `gemini_dom_${index}`;
			if (seenIds.has(id)) return;
			seenIds.add(id);
			const tagName = el.tagName.toLowerCase();
			const classList = el.className || "";
			let role = "assistant";
			if (tagName === "user-query" || classList.includes("query-content") || classList.includes("user")) role = "user";
			messages.push({
				id,
				role,
				text,
				timestamp: Date.now(),
				chatId: conversationId
			});
		});
		return messages;
	}
	document.querySelectorAll("main [class*=\"turn\"], main [class*=\"response\"], main [class*=\"query\"]").forEach((block, index) => {
		const el = block;
		const text = el.innerText?.trim();
		if (!text) return;
		const id = `gemini_dom_fb_${index}`;
		if (seenIds.has(id)) return;
		seenIds.add(id);
		const classList = el.className || "";
		const role = classList.includes("query") || classList.includes("user") ? "user" : "assistant";
		messages.push({
			id,
			role,
			text,
			timestamp: Date.now(),
			chatId: conversationId
		});
	});
	return messages;
}
var GeminiAdapter = class {
	provider = "gemini";
	detect() {
		return window.location.hostname === "gemini.google.com";
	}
	getConversationId() {
		const match = window.location.pathname.match(/\/(?:app|chat)\/([a-zA-Z0-9_-]+)/);
		return match ? match[1] : null;
	}
	async fetchFullConversation(id) {
		console.log(`[Provider] GeminiAdapter requesting API capture for ${id}`);
		return new Promise((resolve, reject) => {
			chrome.runtime.sendMessage({
				type: "REQUEST_API_CAPTURE",
				payload: {
					provider: this.provider,
					id,
					apiBase: window.location.origin
				}
			}, (response) => {
				if (chrome.runtime.lastError) {
					console.error("[API] Message error:", chrome.runtime.lastError.message);
					reject(new Error(chrome.runtime.lastError.message));
					return;
				}
				if (response?.success) try {
					const conversation = parseGeminiApiResponse(id, response.data);
					console.log(`[API] Parsed ${conversation.messages.length} messages from Gemini API`);
					if (conversation.messages.length === 0) {
						reject(/* @__PURE__ */ new Error("Gemini API returned no user/assistant messages"));
						return;
					}
					resolve(conversation);
				} catch (parseError) {
					console.error("[API] Failed to parse Gemini API response");
					reject(parseError instanceof Error ? parseError : new Error(String(parseError)));
				}
				else {
					console.error("[API] Gemini API fetch failed:", response?.error);
					reject(new Error(response?.error || "Unknown API error"));
				}
			});
		});
	}
	async extractFromDom() {
		console.log("[Fallback] GeminiAdapter initiating DOM fallback");
		await scrollToTopToLoadHistory(document.querySelector("[class*=\"overflow-y-auto\"]") ?? document.querySelector("main") ?? document.documentElement);
		const conversationId = this.getConversationId() ?? `gemini_temp_${crypto.randomUUID()}`;
		const messages = extractGeminiDomMessages(conversationId);
		return {
			id: conversationId,
			provider: this.provider,
			title: document.title || "Gemini Conversation",
			messages,
			capturedAt: Date.now(),
			embedding: null
		};
	}
};
//#endregion
//#region src/content/providers/deepseek.ts
function parseDeepSeekApiResponse(conversationId, data) {
	const raw = data;
	const session = raw.data?.biz_data?.chat_session;
	let apiMessages = raw.data?.biz_data?.chat_messages;
	if (!apiMessages && Array.isArray(data.messages)) apiMessages = data.messages;
	const messages = [];
	for (const apiMsg of apiMessages ?? []) {
		const rawRole = (apiMsg.role ?? "").toUpperCase();
		let role;
		if (rawRole === "USER") role = "user";
		else if (rawRole === "ASSISTANT") role = "assistant";
		else continue;
		const text = (apiMsg.content ?? "").trim();
		if (!text) continue;
		const timestamp = apiMsg.inserted_at ? new Date(apiMsg.inserted_at).getTime() : Date.now();
		messages.push({
			id: String(apiMsg.message_id ?? crypto.randomUUID()),
			role,
			text,
			timestamp,
			chatId: conversationId
		});
	}
	return {
		id: conversationId,
		provider: "deepseek",
		title: session?.title?.trim() || document.title || "DeepSeek Conversation",
		messages,
		capturedAt: Date.now(),
		embedding: null
	};
}
function extractDeepSeekDomMessages(conversationId) {
	const messages = [];
	const seenIds = /* @__PURE__ */ new Set();
	const messageContainers = document.querySelectorAll("[class*=\"ds-markdown\"], [class*=\"fbb737a4\"], [class*=\"f9bf7997\"], .chat-message-content, [data-message-author-role]");
	if (messageContainers.length > 0) {
		messageContainers.forEach((container, index) => {
			const el = container;
			const text = el.innerText?.trim();
			if (!text) return;
			const id = `deepseek_dom_${index}`;
			if (seenIds.has(id)) return;
			seenIds.add(id);
			const dataRole = el.getAttribute("data-message-author-role");
			let role;
			if (dataRole) role = dataRole === "user" ? "user" : "assistant";
			else {
				const parentClasses = el.parentElement?.className ?? "";
				role = el.closest("[class*=\"user\"], [class*=\"User\"]") || parentClasses.includes("user") ? "user" : "assistant";
			}
			messages.push({
				id,
				role,
				text,
				timestamp: Date.now(),
				chatId: conversationId
			});
		});
		return messages;
	}
	document.querySelectorAll("main .group, main [class*=\"message\"]").forEach((turn, index) => {
		const text = turn.innerText?.trim();
		if (!text) return;
		const id = `deepseek_dom_fb_${index}`;
		if (seenIds.has(id)) return;
		seenIds.add(id);
		messages.push({
			id,
			role: index % 2 === 0 ? "user" : "assistant",
			text,
			timestamp: Date.now(),
			chatId: conversationId
		});
	});
	return messages;
}
var DeepSeekAdapter = class {
	provider = "deepseek";
	detect() {
		return window.location.hostname === "chat.deepseek.com";
	}
	getConversationId() {
		const match = window.location.pathname.match(/\/(?:a\/)?chat(?:\/s)?\/([a-zA-Z0-9_-]+)/);
		return match ? match[1] : null;
	}
	async fetchFullConversation(id) {
		console.log(`[Provider] DeepSeekAdapter requesting API capture for ${id}`);
		return new Promise((resolve, reject) => {
			chrome.runtime.sendMessage({
				type: "REQUEST_API_CAPTURE",
				payload: {
					provider: this.provider,
					id,
					apiBase: window.location.origin
				}
			}, (response) => {
				if (chrome.runtime.lastError) {
					console.error("[API] Message error:", chrome.runtime.lastError.message);
					reject(new Error(chrome.runtime.lastError.message));
					return;
				}
				if (response?.success) try {
					const conversation = parseDeepSeekApiResponse(id, response.data);
					console.log(`[API] Parsed ${conversation.messages.length} messages from DeepSeek API`);
					if (conversation.messages.length === 0) {
						reject(/* @__PURE__ */ new Error("DeepSeek API returned no user/assistant messages"));
						return;
					}
					resolve(conversation);
				} catch (parseError) {
					console.error("[API] Failed to parse DeepSeek API response");
					reject(parseError instanceof Error ? parseError : new Error(String(parseError)));
				}
				else {
					console.error("[API] DeepSeek API fetch failed:", response?.error);
					reject(new Error(response?.error || "Unknown API error"));
				}
			});
		});
	}
	async extractFromDom() {
		console.log("[Fallback] DeepSeekAdapter initiating DOM fallback");
		await scrollToTopToLoadHistory(document.querySelector("[class*=\"overflow-y-auto\"]") ?? document.querySelector("main") ?? document.documentElement);
		const conversationId = this.getConversationId() ?? `deepseek_temp_${crypto.randomUUID()}`;
		const messages = extractDeepSeekDomMessages(conversationId);
		return {
			id: conversationId,
			provider: this.provider,
			title: document.title || "DeepSeek Conversation",
			messages,
			capturedAt: Date.now(),
			embedding: null
		};
	}
};
//#endregion
//#region src/content/providers/generic.ts
var GenericAdapter = class {
	provider = "generic";
	detect() {
		return true;
	}
	getConversationId() {
		return `generic_${window.location.pathname.replace(/\W+/g, "_") || "root"}`;
	}
	async fetchFullConversation(_id) {
		console.log("[API] GenericAdapter does not support API fetch — forcing fallback");
		throw new Error("API capture not supported on generic sites");
	}
	async extractFromDom() {
		console.log("[Fallback] GenericAdapter extracting from DOM");
		await scrollToTopToLoadHistory(document.querySelector("main") ?? document.querySelector("[class*=\"overflow-y-auto\"]") ?? document.documentElement);
		const conversationId = this.getConversationId();
		const messages = scanFullDom(conversationId);
		return {
			id: conversationId,
			provider: this.provider,
			title: document.title || "Captured Conversation",
			messages,
			capturedAt: Date.now(),
			embedding: null
		};
	}
};
//#endregion
//#region src/content/detector.ts
var registry = [
	new ChatGPTAdapter(),
	new ClaudeAdapter(),
	new GeminiAdapter(),
	new DeepSeekAdapter(),
	new GenericAdapter()
];
function detectProvider() {
	for (const adapter of registry) if (adapter.detect()) return adapter;
	return new GenericAdapter();
}
//#endregion
//#region src/content/mutation-watcher.ts
var MutationWatcher = class {
	observer = null;
	onMessageExtracted;
	constructor(onMessageExtracted) {
		this.onMessageExtracted = onMessageExtracted;
	}
	start() {
		console.log("[Fallback] Starting MutationWatcher");
		this.observer = new MutationObserver((mutations) => this.processMutations(mutations));
		this.observer.observe(document.body, {
			childList: true,
			subtree: true,
			characterData: true
		});
	}
	stop() {
		console.log("[Fallback] Stopping MutationWatcher");
		this.observer?.disconnect();
		this.observer = null;
	}
	processMutations(mutations) {
		for (const mutation of mutations) if (mutation.type === "childList") mutation.addedNodes.forEach((node) => {
			if (node.nodeType === Node.ELEMENT_NODE) {
				const element = node;
				if (element.hasAttribute("data-message-author-role")) this.onMessageExtracted(element);
				element.querySelectorAll("[data-message-author-role]").forEach((child) => this.onMessageExtracted(child));
			}
		});
		else if (mutation.type === "characterData") {
			let target = null;
			if (mutation.target.nodeType === Node.ELEMENT_NODE) target = mutation.target.closest("[data-message-author-role]");
			else if (mutation.target.parentElement) target = mutation.target.parentElement.closest("[data-message-author-role]");
			if (target) this.onMessageExtracted(target);
		}
	}
};
//#endregion
//#region src/content/conversation-capture.ts
function reportProgress(progress) {
	chrome.runtime.sendMessage({
		type: "CAPTURE_PROGRESS",
		progress
	}).catch(() => {});
}
var ConversationCaptureOrchestrator = class {
	watcher;
	constructor() {
		this.watcher = new MutationWatcher((node) => {
			const adapter = detectProvider();
			const conversationId = adapter.getConversationId();
			const msg = extractMessageFromNode(node, conversationId ?? void 0);
			if (!msg || !conversationId) return;
			chrome.runtime.sendMessage({
				type: "NEW_CHAT_MESSAGE",
				payload: {
					message: msg,
					conversation: {
						nativeId: conversationId,
						platform: adapter.provider,
						title: document.title
					}
				}
			});
		});
	}
	initPassiveCapture() {
		this.watcher.start();
	}
	async triggerManualCapture() {
		console.log("[Capture] Orchestration started");
		reportProgress({
			stage: "detect",
			message: "Detecting provider…"
		});
		const adapter = detectProvider();
		console.log(`[Provider] Detected: ${adapter.provider}`);
		const conversationId = adapter.getConversationId();
		if (!conversationId) {
			const error = "No conversation ID found on this page";
			console.warn(`[Capture] ${error}`);
			reportProgress({
				stage: "error",
				message: error,
				provider: adapter.provider
			});
			return {
				success: false,
				provider: adapter.provider,
				error
			};
		}
		console.log(`[Capture] Conversation ID: ${conversationId}`);
		reportProgress({
			stage: "detect",
			message: `Detected ${adapter.provider} conversation`,
			provider: adapter.provider,
			conversationId
		});
		let conversation;
		let usedFallback = false;
		try {
			reportProgress({
				stage: "api",
				message: "Fetching full conversation via API…",
				provider: adapter.provider,
				conversationId
			});
			conversation = await adapter.fetchFullConversation(conversationId);
			console.log(`[Capture] API capture successful (${conversation.messages.length} messages)`);
		} catch (apiError) {
			const reason = apiError instanceof Error ? apiError.message : String(apiError);
			console.warn("[API] API capture failed, falling back to DOM extraction:", reason);
			usedFallback = true;
			reportProgress({
				stage: "fallback",
				message: "API failed — using DOM scroll + extraction…",
				provider: adapter.provider,
				conversationId,
				usedFallback: true
			});
			try {
				conversation = await adapter.extractFromDom();
				console.log(`[Fallback] DOM extraction completed (${conversation.messages.length} messages)`);
			} catch (domError) {
				const domReason = domError instanceof Error ? domError.message : String(domError);
				console.error("[Capture] Both API and DOM extraction failed:", domReason);
				reportProgress({
					stage: "error",
					message: domReason,
					provider: adapter.provider,
					conversationId,
					usedFallback: true
				});
				return {
					success: false,
					provider: adapter.provider,
					conversationId,
					usedFallback: true,
					error: domReason
				};
			}
		}
		const { conversation: deduped, duplicateCount } = this.deduplicate(conversation);
		reportProgress({
			stage: "dedup",
			message: duplicateCount > 0 ? `Removed ${duplicateCount} duplicate message(s)` : "No duplicates found",
			provider: deduped.provider,
			conversationId: deduped.id,
			messageCount: deduped.messages.length,
			duplicateCount,
			usedFallback
		});
		const validation = this.validate(deduped);
		reportProgress({
			stage: "validate",
			message: validation.valid ? `Validated ${deduped.messages.length} messages` : validation.reason ?? "Validation failed",
			provider: deduped.provider,
			conversationId: deduped.id,
			messageCount: deduped.messages.length,
			usedFallback
		});
		if (!validation.valid) {
			console.error("[Validate] Validation failed:", validation.reason);
			return {
				success: false,
				provider: deduped.provider,
				conversationId: deduped.id,
				messageCount: deduped.messages.length,
				usedFallback,
				duplicateCount,
				error: validation.reason
			};
		}
		try {
			await this.saveConversation(deduped);
		} catch (saveError) {
			const saveReason = saveError instanceof Error ? saveError.message : String(saveError);
			reportProgress({
				stage: "error",
				message: saveReason,
				provider: deduped.provider,
				conversationId: deduped.id,
				usedFallback
			});
			return {
				success: false,
				provider: deduped.provider,
				conversationId: deduped.id,
				messageCount: deduped.messages.length,
				usedFallback,
				duplicateCount,
				error: saveReason
			};
		}
		reportProgress({
			stage: "done",
			message: `Saved ${deduped.messages.length} messages`,
			provider: deduped.provider,
			conversationId: deduped.id,
			messageCount: deduped.messages.length,
			duplicateCount,
			usedFallback
		});
		return {
			success: true,
			provider: deduped.provider,
			conversationId: deduped.id,
			messageCount: deduped.messages.length,
			usedFallback,
			duplicateCount
		};
	}
	deduplicate(conv) {
		console.log("[Dedup] Starting deduplication");
		const uniqueMessages = [];
		const seenIds = /* @__PURE__ */ new Set();
		const seenContentKeys = /* @__PURE__ */ new Set();
		for (const msg of conv.messages) {
			const contentKey = `${msg.role}:${msg.text}`;
			if (seenIds.has(msg.id) || seenContentKeys.has(contentKey)) continue;
			seenIds.add(msg.id);
			seenContentKeys.add(contentKey);
			uniqueMessages.push(msg);
		}
		const duplicateCount = conv.messages.length - uniqueMessages.length;
		console.log(`[Dedup] Removed ${duplicateCount} duplicates`);
		return {
			conversation: {
				...conv,
				messages: uniqueMessages
			},
			duplicateCount
		};
	}
	validate(conv) {
		console.log("[Validate] Validating conversation");
		if (!conv.id || !conv.provider) {
			const reason = "Missing conversation ID or provider";
			console.error(`[Validate] ${reason}`);
			return {
				valid: false,
				reason
			};
		}
		if (!conv.messages.length) {
			const reason = "Conversation has no messages";
			console.error(`[Validate] ${reason}`);
			return {
				valid: false,
				reason
			};
		}
		if (conv.messages.find((msg) => !msg.id || !msg.role || !msg.text?.trim())) {
			const reason = "Conversation contains invalid or empty messages";
			console.error(`[Validate] ${reason}`);
			return {
				valid: false,
				reason
			};
		}
		console.log(`[Validate] Passed (${conv.messages.length} messages)`);
		return { valid: true };
	}
	async saveConversation(conversation) {
		console.log(`[Storage] Sending conversation ${conversation.id} to background`);
		reportProgress({
			stage: "storage",
			message: "Saving to Dexie…",
			provider: conversation.provider,
			conversationId: conversation.id,
			messageCount: conversation.messages.length
		});
		return new Promise((resolve, reject) => {
			chrome.runtime.sendMessage({
				type: "SAVE_CONVERSATION",
				payload: { conversation }
			}, (response) => {
				if (chrome.runtime.lastError) {
					console.error("[Storage] Background communication failed:", chrome.runtime.lastError.message);
					reject(new Error(chrome.runtime.lastError.message));
					return;
				}
				if (response?.success) {
					console.log(`[Storage] Saved ${conversation.messages.length} messages`);
					resolve();
				} else {
					console.error("[Storage] Failed to save conversation:", response?.error);
					reject(new Error(response?.error || "Save failed"));
				}
			});
		});
	}
};
var orchestrator = new ConversationCaptureOrchestrator();
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
	if (message.type === "TRIGGER_CAPTURE") {
		orchestrator.triggerManualCapture().then((result) => sendResponse(result)).catch((error) => sendResponse({
			success: false,
			error: error.message ?? String(error)
		}));
		return true;
	}
	if (message.type === "GET_CONVERSATION_INFO") {
		const adapter = detectProvider();
		sendResponse({
			nativeId: adapter.getConversationId(),
			platform: adapter.provider,
			title: document.title
		});
		return false;
	}
	if (message.type === "INJECT_AND_SEND") {
		injectTextAndSend(message.payload?.text ?? "");
		sendResponse({ success: true });
		return false;
	}
	return false;
});
/**
* Finds the chat input on the current page, injects the given text,
* and triggers the send button / Enter key.
*/
function injectTextAndSend(text) {
	const selectors = [
		"#prompt-textarea",
		"div[contenteditable=\"true\"].ProseMirror",
		"div[contenteditable=\"true\"]",
		"textarea"
	];
	let input = null;
	for (const sel of selectors) {
		input = document.querySelector(sel);
		if (input) break;
	}
	if (!input) {
		console.error("[Transfer] Could not find chat input on this page.");
		return;
	}
	if (input.getAttribute("contenteditable") === "true") {
		input.focus();
		input.innerHTML = "";
		text.split("\n").forEach((line) => {
			const p = document.createElement("p");
			p.textContent = line || "​";
			input.appendChild(p);
		});
		input.dispatchEvent(new Event("input", { bubbles: true }));
	} else if (input instanceof HTMLTextAreaElement) {
		(Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set)?.call(input, text);
		input.dispatchEvent(new Event("input", { bubbles: true }));
	}
	setTimeout(() => {
		const sendSelectors = [
			"button[data-testid=\"send-button\"]",
			"button[aria-label=\"Send Message\"]",
			"button.send-button",
			"button[aria-label=\"Send\"]",
			"button[type=\"submit\"]"
		];
		let sendBtn = null;
		for (const sel of sendSelectors) {
			sendBtn = document.querySelector(sel);
			if (sendBtn) break;
		}
		if (sendBtn) sendBtn.click();
		else {
			const enterEvent = new KeyboardEvent("keydown", {
				key: "Enter",
				code: "Enter",
				bubbles: true,
				cancelable: true
			});
			input.dispatchEvent(enterEvent);
		}
	}, 300);
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => orchestrator.initPassiveCapture());
else orchestrator.initPassiveCapture();
//#endregion
export { ConversationCaptureOrchestrator };
